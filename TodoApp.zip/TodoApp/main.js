const express = require("express");
const app = express();

app.use(express.json());

const port = process.env.port || 4000;

const todoRoutes = require("./routes/index");
app.use("/api/v1",todoRoutes);


app.listen(port,()=>{
    console.log("App Started at port no 3000");
})

const dbConnect = require("./config/database");
dbConnect();

app.get('/',(req,res)=>{
    res.send("<i><h3>hey createTodo done</h3></i>");
})
