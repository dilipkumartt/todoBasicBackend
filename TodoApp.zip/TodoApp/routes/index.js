const express = require("express");
const router = express.Router();

const {createTodo} = require("../controllers/createTodo");
const {getAllTodos} = require("../controllers/getAllTodos");
const {deleteAllTodos} = require("../controllers/deleteAllTodo");
const {getSingleTodo} = require("../controllers/getTodoById");
const {deleteTodo}  = require("../controllers/deleteTodoById");
const {updateTodo} = require("../controllers/updateTodoById");

router.post("/createTodo",createTodo);
router.get("/getAllTodo",getAllTodos);
router.delete("/deleteAllTodo",deleteAllTodos);
router.get("/getAllTodo/:id",getSingleTodo);
router.delete("/deleteAllTodo/:id",deleteTodo);
router.put("/updatedTodoById/:id",updateTodo);


module.exports = router;
