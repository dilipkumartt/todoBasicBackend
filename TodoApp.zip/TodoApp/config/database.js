const mongoose = require("mongoose");
require("dotenv").config(); // using .env files to current file

const dbConnection = ()=>{
    mongoose.connect(process.env.database_url,
        {
            useNewUrlParser:true,
            useUnifiedTopology:true
        }
    )
    .then((res)=>{
        console.log("db connection successful");
    })
    .catch((err)=>{
        console.log("error"
        );
    })
}

module.exports = dbConnection;