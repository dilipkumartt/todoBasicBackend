const Todo = require("../models/todo");

exports.getSingleTodo = async(req,res)=>{
    try{
        const todoId = req.params.id;
        const todos = await Todo.findById( {_id:todoId} );

        if(!todos){
            return res.status(404).json(
                {
                    success:false,
                    message:"no data"
                }
            )
        }

        res.status(200).json(
            {
                success:true,
                data:todos,
                message:"heywe got it"
            }
        )

    }
    catch(err){

        console.log(err);
        res.status(408).json(
            {
                success:false,
                message:"failed"
            }
        )

    }
}