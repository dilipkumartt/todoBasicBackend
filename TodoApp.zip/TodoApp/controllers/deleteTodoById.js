const Todo = require("../models/todo");

exports.deleteTodo = async(req,res)=>{

    try{
        const todoId = req.params.id;
        const deleteTodoid = await Todo.findByIdAndDelete({_id: todoId});
        if(!deleteTodoid){
            return res.status(404).json(
                {
                    success:false,
                    message:"id not found"
                }
            )
        }
        res.status(200).json(
            {
                success:true,
                data:deleteTodoid,
                message:"todo deleted sucessfully"
            }
        )
    }
    catch(err){
        console.log(err.message);
        res.status(404).json(
            {
                success:false,
                message:"failed"
            }
        )
    }
}