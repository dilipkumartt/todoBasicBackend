const Todo = require("../models/todo");

exports.getAllTodos = async(req,res)=>{
    
    try{
        const allTodos = await  Todo.find({});

        res.status(200).json(
            {
                success:true,
                data:allTodos,
                message:"sucessfully fetched all Todos",
            }
        )
    }
    catch(err){
        console.log(err.message);
        res.status(500).json(
            {
                success:false,
                data:"internal  server error",
                message:"failed to fecth all todos"
            }
        )
    }
}
// module.exports= {getAllTodos};