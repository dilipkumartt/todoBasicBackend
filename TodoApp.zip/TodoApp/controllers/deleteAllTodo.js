const Todo = require("../models/todo");

exports.deleteAllTodos = async(req,res)=>{

    try{
        const allTodos = await Todo.deleteMany({});
        // allTodos.length = 0;
        res.status(200).json(
            {
                success:true,
                data:allTodos,
                message:"deleted successfully"
            }
        )
    }
    catch(err){
        res.status(200).json(
            {
                success:false,
                data:"failed",
                message:"not deleted successfully"
            }
        )
    }
}